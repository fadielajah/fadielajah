
<html>
<head>
 <title>LOGIN MULTIUSER PHP</title>
 <link rel="stylesheet" type="text/css" href="styleee.css">
</head>
<body>


 <?php
 if(isset($_GET['pesan'])){
  if($_GET['pesan']=="gagal"){
   echo "<br><h5><center>Username dan Password Salah!</center>";
  }
 }
 ?>

 <div class="panel_login">
  <center><img src="logo1.png" width="300 px" height="95 px"></center><br>

  <form action="cekkoneksi.php" method="post">
   
   <input type="text" name="username" class="form_login" placeholder="Username" required="required">

   
   <input type="password" name="password" class="form_login" placeholder="Password" required="required">

   <input type="submit" class="tombol_login" value="LOGIN">

   <br/>
   <br/>
   
  </form>
  
 </div>
 <div class="copy">
<center>Universitas Panca Marga - Copyright by Sam Fadiel</center>
</div>
</body>
</html>